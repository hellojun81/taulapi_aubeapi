// instagram.ts
import { fetchMetaAds } from './meta';
export const fetchInstagramAds = fetchMetaAds; // 메타와 동일하게 처리