// // routes/customers.js
// import express from 'express';
// import bankController from '../../controllers/crm/bankController.js';

// const router = express.Router();

// //추가
// // router.post('/', bankService.addCustomer);
// //검색
// router.get('/', bankController.getBankTransactions);
// // //ID값검색
// // router.get('/:id', bankService.getCustomerById);
// // //수정
// // router.put('/:id', bankService.updateCustomer);
// // //삭제
// // router.delete('/:id', bankService.deleteCustomer);

// export default router;
